package test;
import dao.UsersDAO;
import model.Login;
import model.Users;
import model.UsersEntry;

public class UsersDAOTest {
  public static void main(String[] args) {
	testFindByLoginOK();		// ユーザーが見つかる場合のテスト
	testFindByLoginNG();		// ユーザーが見つからない場合のテスト
	testFindByUserOK();		// ユーザーが見つかる場合のテスト
	testFindByUserNG();		// ユーザーが見つからない場合のテスト
	testInsertByEntryOK();		// テーブル挿入が成功する場合のテスト
  }
  public static void testFindByLoginOK() {
	Login login = new Login("c036803", "c036803");
	UsersDAO dao = new UsersDAO();
	Users result = dao.findByLogin(login);
	if (result != null && result.getUserId().equals("c036803") && result.getPass().equals("c036803") &&
	    result.getNameKanji().equals("○○　○○") && result.getNameKana().equals("○○○　○○○○") &&
	    result.getSex().equals("M") && result.getMail().equals("XXX@mail.jp") && 
	    result.getTel().equals("123-456-7890")) {
	  System.out.println("testFindByLoginOK:成功しました");
	} else {
	  System.out.println("testFindByLoginOK:失敗しました");
	  System.out.println("UserId:" + result.getUserId());
	  System.out.println("Pass:" + result.getPass());
	  System.out.println("NameKanji:" + result.getNameKanji());
	  System.out.println("NameKana:" + result.getNameKana());
	  System.out.println("Sex:" + result.getSex());
	  System.out.println("Mail:" + result.getMail());
	  System.out.println("Tel:" + result.getTel());
	}
  }
  public static void testFindByLoginNG() {
	Login login = new Login("c036803", "12345");
	UsersDAO dao = new UsersDAO();
	Users result = dao.findByLogin(login);
	if (result == null) {
	  System.out.println("testFindByLoginNG:成功しました");
	} else {
	  System.out.println("testFindByLoginNG:失敗しました");
	}
  }
  public static void testFindByUserOK() {
	UsersEntry usersEntry = new UsersEntry("c036803", "c036803", "○○　○○", "○○○　○○○○", "M", "XXX@mail.jp",
										   "123-456-7890");
	UsersDAO dao = new UsersDAO();
	Users result = dao.findByUser(usersEntry);
	if (result != null && result.getUserId().equals("c036803") && result.getPass().equals("c036803") &&
		result.getNameKanji().equals("○○　○○") && result.getNameKana().equals("○○○　○○○○") &&
		result.getSex().equals("M") && result.getMail().equals("XXX@mail.jp") &&
		result.getTel().equals("123-456-7890")) {
	  System.out.println("testFindByUserOK:成功しました");
	} else {
	  System.out.println("testFindByUserOK:失敗しました");
	}
  }
  public static void testFindByUserNG() {
	UsersEntry usersEntry = new UsersEntry("12345", "c036803", "木本　寿彦", "キモト　トシヒコ", "M", "c036803@yahoo.co.jp",
										   "090-2097-4066");
	UsersDAO dao = new UsersDAO();
	Users result = dao.findByUser(usersEntry);
	if (result == null) {
	  System.out.println("testFindByUserNG:成功しました");
	} else {
	  System.out.println("testFindByUserNG:失敗しました");
	}
  }
  public static void testInsertByEntryOK() {
	UsersEntry usersEntry = new UsersEntry("12345", "c036803", "木本　寿彦", "キモト　トシヒコ", "M", "c036803@yahoo.co.jp",
										   "090-2097-4066");
	UsersDAO dao = new UsersDAO();
	boolean result = dao.insertByEntry(usersEntry);
	if (result == true) {
	  System.out.println("testInsertByEntry:成功しました");
	} else {
	  System.out.println("testInsertByEntry:失敗しました");
	}
  }
}
