package test;

import java.util.List;

import dao.AnswerDAO;
import dao.QuizDAO;
import model.Answer;
import model.Quiz;

public class QuizControlTest {
  public static void main(String[] args) {
		QuizDAO dao1 = new QuizDAO();
		List<Quiz> quizList = dao1.findSelect();
		AnswerDAO dao2 = new AnswerDAO();

	    
	    if (quizList != null) {
	      for (Quiz qz : quizList) {
	        System.out.print(qz.getQuizChapterId() + " ");
	        System.out.print(qz.getQuizId() + " ");
	        System.out.println(qz.getQuiz());
	        List<Answer> answerList = dao2.findSelect(qz);
	        
	        if (answerList != null) {
	          for (Answer as : answerList) {
	            System.out.print(as.getQuizChapterId()+ " ");
	            System.out.print(as.getQuizId() + " ");
	            System.out.print(as.getAnswerId() + " ");
	            System.out.println(as.getAnswer());
	            System.out.println(as.getAnswerFlg());
              }
	        }
	      }
	    }
  }
}
