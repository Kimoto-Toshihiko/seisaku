package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Quiz;

public class QuizDAO {
  private final String JDBC_URL = "jdbc:h2:tcp://localhost/~/test";
  private final String DB_USER = "sa";
  private final String DB_PASS = "";

  public List<Quiz> findSelect() {
    List<Quiz> quizList = new ArrayList<>();
    try {
      Class.forName("org.h2.Driver");
    } catch (ClassNotFoundException e) {
      throw new IllegalStateException("JDBCドライバを読み込めませんでした");
    }
    try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
      String sql = "SELECT QUIZ_CHAPTER_ID, QUIZ_ID, QUIZ, ANSWER_NUM, CORR_ANSWER_NUM FROM QUIZ ORDER BY RANDOM() LIMIT 10";
      PreparedStatement pStmt = conn.prepareStatement(sql);
      ResultSet rs = pStmt.executeQuery();
      while (rs.next()) {
        int quizChapterId = rs.getInt("QUIZ_CHAPTER_ID");
        int quizId = rs.getInt("QUIZ_ID");
        String quiz = rs.getString("QUIZ");
        int answerNum = rs.getInt("ANSWER_NUM");
        int corrAnswerNum = rs.getInt("CORR_ANSWER_NUM");
        Quiz qz = new Quiz(quizChapterId, quizId, quiz, answerNum, corrAnswerNum);
        quizList.add(qz);
      }
    } catch (SQLException e) {
      e.printStackTrace();
      return new ArrayList<>(); // 空のリストを返す
    }
    return quizList;
  }
}
