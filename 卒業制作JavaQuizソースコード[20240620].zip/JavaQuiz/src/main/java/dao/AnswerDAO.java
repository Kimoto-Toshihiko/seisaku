package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Answer;
import model.Quiz;

public class AnswerDAO {
  private final String JDBC_URL = "jdbc:h2:tcp://localhost/~/test";
  private final String DB_USER = "sa";
  private final String DB_PASS = "";

  public List<Answer> findSelect(Quiz qz) {
    List<Answer> answerList = new ArrayList<>();
    try {
      Class.forName("org.h2.Driver");
    } catch (ClassNotFoundException e) {
      throw new IllegalStateException("JDBCドライバを読み込めませんでした");
    }
    try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
      String sql = "SELECT DISTINCT a.QUIZ_CHAPTER_ID, a.QUIZ_ID, ANSWER_ID, ANSWER, ANSWER_FLG FROM ANSWER a "
          + "INNER JOIN QUIZ q ON a.QUIZ_CHAPTER_ID = q.QUIZ_CHAPTER_ID AND a.QUIZ_ID = q.QUIZ_ID "
          + "WHERE a.QUIZ_CHAPTER_ID = ? AND a.QUIZ_ID = ? "
          + "ORDER BY a.QUIZ_CHAPTER_ID, a.QUIZ_ID, ANSWER_ID ASC";
      PreparedStatement pStmt = conn.prepareStatement(sql);
      pStmt.setInt(1, qz.getQuizChapterId());
      pStmt.setInt(2, qz.getQuizId());
      ResultSet rs = pStmt.executeQuery();
      while (rs.next()) {
        int quizChapterId = rs.getInt("QUIZ_CHAPTER_ID");
        int quizId = rs.getInt("QUIZ_ID");
        int answerId = rs.getInt("ANSWER_ID");
        String answer = rs.getString("ANSWER");
        String answerFlg = rs.getString("ANSWER_FLG");
        Answer as = new Answer(quizChapterId, quizId, answerId, answer, answerFlg);
        answerList.add(as);
      }
    } catch (SQLException e) {
      e.printStackTrace();
      return new ArrayList<>(); // 空のリストを返す
    }
    return answerList;
  }
}

