package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.Login;
import model.Users;
import model.UsersEntry;

public class UsersDAO {
  private final String JDBC_URL = "jdbc:h2:tcp://localhost/~/test";
  private final String DB_USER = "sa";
  private final String DB_PASS = "";
  
  public Users findByLogin(Login login) {
	Users users = null;
	// JDBCドライバを読み込む
	try {
	  Class.forName("org.h2.Driver");
	} catch (ClassNotFoundException e) {
		throw new IllegalStateException("JDBCドライバを読み込めませんでした");
	}
	// データベースへ接続
	try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
	  // SELECT文を準備
	  String sql = "SELECT USER_ID, PASS, NAME_KANJI, NAME_KANA, SEX, MAIL, TEL FROM USERS WHERE USER_ID = ? AND PASS = ?";
	  PreparedStatement pStmt = conn.prepareStatement(sql);
	  pStmt.setString(1, login.getUserId());
	  pStmt.setString(2, login.getPass());
	  
	  // SELECT文を実行し、結果表を取得
	  ResultSet rs = pStmt.executeQuery();
	  
	  if (rs.next()) {
		// ユーザーが存在したらデータを取得
		// そのユーザーを表すUsersインスタンスを生成
		String userId = rs.getString("USER_ID");
		String pass = rs.getString("PASS");
		String nameKanji = rs.getString("NAME_KANJI");
		String nameKana = rs.getString("NAME_KANA");
		String sex = rs.getString("SEX");
		String mail = rs.getString("MAIL");
		String tel = rs.getString("TEL");
		users = new Users(userId, pass, nameKanji, nameKana, sex, mail, tel);
	  }
	} catch (SQLException e) {
		e.printStackTrace();
		return null;
	}
	return users;
  }
  public Users findByUser(UsersEntry usersEntry) {
	Users users = null;
	// JDBCドライバを読み込む
	try {
	  Class.forName("org.h2.Driver");
	} catch (ClassNotFoundException e) {
	    throw new IllegalStateException("JDBCドライバを読み込めませんでした");
	}
	// データベースへ接続
	try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
	  // SELECT文を準備
	  String sql = "SELECT USER_ID, PASS, NAME_KANJI, NAME_KANA, SEX, MAIL, TEL FROM USERS WHERE USER_ID = ?";
	  PreparedStatement pStmt = conn.prepareStatement(sql);
	  pStmt.setString(1, usersEntry.getUserId());
	  
	  // SELECT文を実行し、結果表を取得
	  ResultSet rs = pStmt.executeQuery();
	  
	  if (rs.next()) {
		// そのユーザーが存在したらデータを取得
		// そのユーザーを表すUsersインスタンスを生成
		String userId = rs.getString("USER_ID");
		String pass = rs.getString("PASS");
		String nameKanji = rs.getString("NAME_KANJI");
		String nameKana = rs.getString("NAME_KANA");
		String sex = rs.getString("SEX");
		String mail = rs.getString("MAIL");
		String tel = rs.getString("TEL");
		users = new Users(userId, pass, nameKanji, nameKana, sex, mail, tel);
	  }
	} catch (SQLException e) {
		e.printStackTrace();
		return null;
	}
	return users;
  }
  public boolean insertByEntry(UsersEntry usersEntry) {
	// JDBCドライバを読み込む
	try {
	  Class.forName("org.h2.Driver");
	} catch (ClassNotFoundException e) {
	    throw new IllegalStateException("JDBCドライバを読み込めませんでした");
	}
	// データベースへ接続
	try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
	  // INSERT文を準備
	  String sql = "INSERT INTO USERS ( USER_ID,PASS,NAME_KANJI,NAME_KANA,SEX,MAIL,TEL ) VALUES (?,?,?,?,?,?,?)";
	  PreparedStatement pStmt = conn.prepareStatement(sql);
	  pStmt.setString(1, usersEntry.getUserId());
	  pStmt.setString(2, usersEntry.getPass());
	  pStmt.setString(3, usersEntry.getNameKanji());
	  pStmt.setString(4, usersEntry.getNameKana());
	  pStmt.setString(5, usersEntry.getSex());
	  pStmt.setString(6, usersEntry.getMail());
	  pStmt.setString(7, usersEntry.getTel());
	  
	  // INSERT文を実行(resultには追加された行数が代入される)
	  int result = pStmt.executeUpdate();
	  
	  if (result != 1) {
		return false;
	  }
	} catch (SQLException e) {
		e.printStackTrace();
		return false;
	}
	return true;
  }
}
