package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import model.UsersGrade;

public class UsersGradeDAO {
  private final String JDBC_URL = "jdbc:h2:tcp://localhost/~/test";
  private final String DB_USER = "sa";
  private final String DB_PASS = "";

  public boolean insertGrade(UsersGrade grade) {
	// JDBCドライバを読み込む
	try {
	  Class.forName("org.h2.Driver");
	} catch (ClassNotFoundException e) {
	    throw new IllegalStateException("JDBCドライバを読み込めませんでした");
	}
	// データベースへ接続
	try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
	  // INSERT文を準備
	  String sql = "INSERT INTO USER_GRADE ( USER_ID, ANSWERED_DATE, ANSWERED_GRADE ) VALUES (?, ?, ?)";
	  PreparedStatement pStmt = conn.prepareStatement(sql);
	  pStmt.setString(1, grade.getUserId());
	  pStmt.setDate(2, new java.sql.Date(grade.getAnsweredDate().getTime()));
	  pStmt.setInt(3, grade.getAnsweredGrade());
	  
	  // INSERT文を実行(resultには追加された行数が代入される)
	  int result = pStmt.executeUpdate();
	  
	  if (result == 1) {
	      System.out.println("成績がデータベースに正常に保存されました。");
	      return true;
	  } else {
	      System.out.println("成績の保存に失敗しました。");
	      return false;
	  }
    } catch (SQLException e) {
      e.printStackTrace();
      return false;
    }
  }
}