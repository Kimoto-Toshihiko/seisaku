package servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.AnswerDAO;
import dao.QuizDAO;
import model.Answer;
import model.Quiz;
import model.QuizScreen;

@WebServlet("/QuizControlServlet")
public class QuizControlServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // セッションからユーザーIDを取得
        HttpSession session = request.getSession();
        String userId = (String) session.getAttribute("userId");
        QuizDAO dao1 = new QuizDAO();
        List<Quiz> quizList = dao1.findSelect();
        AnswerDAO dao2 = new AnswerDAO();
        List<QuizScreen> quizScreens = new ArrayList<>();

        if (quizList != null) {
            int i = 0;
            for (Quiz qz : quizList) {
                i++;
                QuizScreen quizScreen = new QuizScreen();
                quizScreen.setUserId(userId);
                quizScreen.setQuizNo(i);
                quizScreen.setQuizChapterId(qz.getQuizChapterId());
                quizScreen.setQuizId(qz.getQuizId());
                quizScreen.setQuiz(qz.getQuiz());
                quizScreen.setAnswerNum(qz.getAnswerNum());
                quizScreen.setCorrAnswerNum(qz.getCorrAnswerNum());
                List<Answer> answerList = dao2.findSelect(qz);

                if (answerList != null) {
                    int[] answerIds = new int[answerList.size()];
                    String[] answers = new String[answerList.size()];
                    String[] answerFlgs = new String[answerList.size()];

                    for (int j = 0; j < answerList.size(); j++) {
                        Answer as = answerList.get(j);
                        answerIds[j] = as.getAnswerId();
                        answers[j] = as.getAnswer();
                        answerFlgs[j] = as.getAnswerFlg();
                    }

                    quizScreen.setAnswerId(answerIds);
                    quizScreen.setAnswer(answers);
                    quizScreen.setAnswerFlg(answerFlgs);
                }

                quizScreens.add(quizScreen);
            }
            session.setAttribute("quizScreens", quizScreens); // セッションに保存する
            RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/quizQuestions.jsp");
            dispatcher.forward(request, response);
        } else {
            request.setAttribute("errorMessage", "クイズが見つかりませんでした。");
            RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/quizQuestions.jsp");
            dispatcher.forward(request, response);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
