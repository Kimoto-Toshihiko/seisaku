package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.QuizScreen;

@WebServlet("/AnswerJudgeServlet")
public class AnswerJudgeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        List<QuizScreen> quizScreens = (List<QuizScreen>) session.getAttribute("quizScreens");

        if (quizScreens != null) {
            for (QuizScreen quizScreen : quizScreens) {
                String quizResult = "○";
                String[] judgeFlg = new String[quizScreen.getAnswerId().length];
                String[] answeredFlg = new String[quizScreen.getAnswerId().length];

                for (int i = 0; i < quizScreen.getAnswerId().length; i++) {
                    String paramName = "answer" + quizScreen.getQuizNo() + "_" + quizScreen.getAnswerId()[i];
                    String paramValue = request.getParameter(paramName);

                    if ("1".equals(quizScreen.getAnswerFlg()[i]) && paramValue != null) {
                        judgeFlg[i] = "○";
                        answeredFlg[i] = "checked";
                    } else if ("1".equals(quizScreen.getAnswerFlg()[i]) && paramValue == null) {
                        judgeFlg[i] = "◎";
                        quizResult = "×";
                        answeredFlg[i] = "";
                    } else if ("0".equals(quizScreen.getAnswerFlg()[i]) && paramValue != null) {
                        judgeFlg[i] = "×";
                        quizResult = "×";
                        answeredFlg[i] = "checked";
                    } else {
                        judgeFlg[i] = "　";
                        answeredFlg[i] = "";
                    }
                }
                quizScreen.setJudgeFlg(judgeFlg);
                quizScreen.setAnsweredFlg(answeredFlg);
                quizScreen.setQuizFlg("×".equals(quizResult) ? "0" : "1");
            }
        }

        session.setAttribute("quizScreens", quizScreens);
        RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/quizResult.jsp");
        dispatcher.forward(request, response);
    }
}
