package servlet;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.QuizScreen;
import model.UsersGrade;
import model.UsersGradeLogic;

@WebServlet("/GradeControlServlet")
public class GradeControlServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        List<QuizScreen> quizScreens = (List<QuizScreen>) session.getAttribute("quizScreens");
        String userId = (String) session.getAttribute("userId");
        int quizResult = 0;

        if (quizScreens != null) {
            for (QuizScreen quizScreen : quizScreens) {
                if ("1".equals(quizScreen.getQuizFlg())) {
                	quizResult += 10;
                }
            }
        }
        UsersGrade usersgrade = new UsersGrade(userId, 0, new Date(), quizResult);
        UsersGradeLogic usersGradeLogic = new UsersGradeLogic();
        usersGradeLogic.execute(usersgrade);

        if (usersgrade != null) {
            session.setAttribute("quizResult", quizResult);
        } else {
            request.setAttribute("errorMessage", "成績の保存に失敗しました。");
        }

        RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/gradeResult.jsp");
        dispatcher.forward(request, response);
    }
}
