package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.UsersEntry;
import model.UsersEntryLogic;
import model.UsersLogic;

/**
 * Servlet implementation class UsersEntryServlet
 */
@WebServlet("/UsersEntryServlet")
public class UsersEntryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
//    public UsersEntryServlet() {
//        super();
        // TODO Auto-generated constructor stub
//    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// フォワード
		RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/usersEntry.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// リクエストパラメータの取得
		request.setCharacterEncoding("UTF-8");
		String userId = request.getParameter("userId");
		String pass = request.getParameter("pass");
		String name_Kanji = request.getParameter("name_Kanji");
		String name_Kana = request.getParameter("name_Kana");
		String sex = request.getParameter("sex");
		String mail = request.getParameter("mail");
		String tel = request.getParameter("tel");
		
		// ユーザーID確認の実行
		UsersEntry usersEntry = new UsersEntry(userId, pass, name_Kanji, name_Kana, sex, mail, tel);
		UsersLogic bo1 = new UsersLogic();
		boolean result1 = bo1.execute(usersEntry);
		
		// ユーザーID確認の成否によって処理を分岐
		if (result1) {			// ユーザーID確認時
		  // リダイレクト
		  response.sendRedirect("UsersEntryServlet");
		} else {				// ユーザーID未確認時
		  // ユーザー登録処理
		  UsersEntryLogic bo2 = new UsersEntryLogic();
		  boolean result2 = bo2.execute(usersEntry);
		  if (result2) {
		    // セッションスコープにユーザーIDを保存
		    HttpSession session = request.getSession();
		    session.setAttribute("userId", userId);

		    // フォワード
		    RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/usersEntryOK.jsp");
		    dispatcher.forward(request, response);
		  } else {
			// リダイレクト
			response.sendRedirect("UsersEntryServlet");
		  }
		}
	}
}
