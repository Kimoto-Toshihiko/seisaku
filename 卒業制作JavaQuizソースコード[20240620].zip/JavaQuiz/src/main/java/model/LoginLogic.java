package model;

import dao.UsersDAO;

public class LoginLogic {
  public boolean execute(Login login) {
	UsersDAO dao = new UsersDAO();
	Users users = dao.findByLogin(login);
	return users != null;
  }

}
