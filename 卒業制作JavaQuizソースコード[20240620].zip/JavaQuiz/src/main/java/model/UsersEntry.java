package model;

public class UsersEntry {
  private String userId;
  private String pass;
  private String nameKanji;
  private String nameKana;
  private String sex;
  private String mail;
  private String tel;
  
  public UsersEntry(String userId, String pass, String nameKanji,String nameKana, String sex, String mail, String tel) {
	this.userId = userId;
	this.pass = pass;
	this.nameKanji = nameKanji;
	this.nameKana = nameKana;
	this.sex = sex;
	this.mail = mail;
	this.tel = tel;
  }
  public String getUserId() { return userId; }
  public String getPass() { return pass; }
  public String getNameKanji() { return nameKanji; }
  public String getNameKana() { return nameKana; }
  public String getSex() { return sex; }
  public String getMail() { return mail; }
  public String getTel() { return tel; }
}
