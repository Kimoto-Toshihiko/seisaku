package model;

public class Quiz {
  private int quizChapterId;
  private int quizId;
  private String quiz;
  private int answerNum;
  private int corrAnswerNum;

  public Quiz(int quizChapterId, int quizId, String quiz, int answerNum, int corrAnswerNum) {
    this.quizChapterId = quizChapterId;
    this.quizId = quizId;
    this.quiz = quiz;
    this.answerNum = answerNum;
    this.corrAnswerNum = corrAnswerNum;
  }

  public int getQuizChapterId() { return quizChapterId; }
  public int getQuizId() { return quizId; }
  public String getQuiz() { return quiz; }
  public int getAnswerNum() { return answerNum; }
  public int getCorrAnswerNum() { return corrAnswerNum; }
}
