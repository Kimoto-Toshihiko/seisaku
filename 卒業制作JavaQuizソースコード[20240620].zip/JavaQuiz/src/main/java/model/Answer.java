package model;

public class Answer {
  private int quizChapterId;
  private int quizId;
  private int answerId;
  private String answer;
  private String answerFlg;

  public Answer(int quizChapterId, int quizId, int answerId, String answer, String answerFlg) {
    this.quizChapterId = quizChapterId;
    this.quizId = quizId;
    this.answerId = answerId;
    this.answer = answer;
    this.answerFlg = answerFlg;
  }

  public int getQuizChapterId() { return quizChapterId; }
  public int getQuizId() { return quizId; }
  public int getAnswerId() { return answerId; }
  public String getAnswer() { return answer; }
  public String getAnswerFlg() { return answerFlg; }
}
