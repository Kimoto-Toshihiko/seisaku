package model;

import java.util.Date;

public class UsersGrade {
  private String userId;
  private int gradeId;
  private Date answeredDate;
  private int answeredGrade;
			  
  public UsersGrade(String userId,int gradeId, Date answeredDate, int answeredGrade) {
	this.userId = userId;
	this.gradeId = gradeId;
	this.answeredDate = answeredDate;
	this.answeredGrade = answeredGrade;
  }
  public String getUserId() { return userId; }
  public int getGradeId() { return gradeId; }
  public Date getAnsweredDate() { return answeredDate; }
  public int getAnsweredGrade() { return answeredGrade; }
}
