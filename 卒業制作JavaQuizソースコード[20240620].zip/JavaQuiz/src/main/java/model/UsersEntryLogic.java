package model;

import dao.UsersDAO;

public class UsersEntryLogic {
  public boolean execute(UsersEntry usersEntry) {
	UsersDAO dao = new UsersDAO();
	boolean result = dao.insertByEntry(usersEntry);
	return result;
  }
}
