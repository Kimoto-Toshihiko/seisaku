package model;

import dao.UsersDAO;

public class UsersLogic {
  public boolean execute(UsersEntry usersEntry) {
	UsersDAO dao = new UsersDAO();
	Users users = dao.findByUser(usersEntry);
	return users != null;
  }
}
