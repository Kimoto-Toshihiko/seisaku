package model;

import dao.UsersGradeDAO;

public class UsersGradeLogic {
  public boolean execute(UsersGrade grade) {
	UsersGradeDAO dao = new UsersGradeDAO();
	boolean usersgrade = dao.insertGrade(grade);
	return usersgrade;
  }

}
