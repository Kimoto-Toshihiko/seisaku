package model;

import java.io.Serializable;

public class QuizScreen implements Serializable {
  private String userId;
  private int quizResult;
  private int quizNo;
  private int quizChapterId;
  private int quizId;
  private String quiz;
  private String quizFlg;
  private int answerNum;
  private int corrAnswerNum;
  private int[] answerId;
  private String[] answer;
  private String[] answerFlg;
  private String[] answeredFlg;
  private String[] judgeFlg;
  
  public QuizScreen() {}
  
  public QuizScreen(String userId, int quizResult, int quizNo, int quizChapterId, int quizId, String quiz, String quizFlg, 
		  	 int answerNum, int corrAnswerNum, int answerId[], String answer[], String answerFlg[], String answeredFlg[], 
		  	 String judgeFlg[]) {
	this.userId = userId;
	this.quizResult = quizResult;
	this.quizNo = quizNo;
	this.quizChapterId = quizChapterId;
	this.quizId = quizId;
	this.quiz = quiz;
	this.quizFlg = quizFlg;
	this.answerNum = answerNum;
	this.corrAnswerNum = corrAnswerNum;
	if (answerId != null && answerId.length > 0) {
	  this.answerId = answerId;
	} else {
	  this.answerId = new int[0];
	}
	if (answer != null && answer.length > 0) {
	  this.answer = answer;
	} else {
	  this.answer = new String[0];
	}
	if (answerFlg != null && answerFlg.length > 0) {
	  this.answerFlg = answerFlg;
	} else {
	  this.answerFlg = new String[0];
	}
	if (answeredFlg != null && answeredFlg.length > 0) {
	  this.answeredFlg = answeredFlg;
	} else {
	  this.answeredFlg = new String[0];
	}
	if (judgeFlg != null && judgeFlg.length > 0) {
	  this.judgeFlg = judgeFlg;
	} else {
	  this.judgeFlg = new String[0];
	}
  }
  public String getUserId() { return userId; }
  public int getQuizResult() { return quizResult; }
  public int getQuizNo() { return quizNo; }
  public int getQuizChapterId() { return quizChapterId; }
  public int getQuizId() { return quizId; }
  public String getQuiz() { return quiz; }
  public String getQuizFlg() { return quizFlg; }
  public int getAnswerNum() { return answerNum; }
  public int getCorrAnswerNum() { return corrAnswerNum; }
  public int[] getAnswerId() { return answerId; }
  public String[] getAnswer() { return answer; }
  public String[] getAnswerFlg() { return answerFlg; }
  public String[] getAnsweredFlg() { return answeredFlg; }
  public String[] getJudgeFlg() { return judgeFlg; }
  public void setUserId(String userId) { this.userId = userId; }
  public void setQuizResult(int quizResult) { this.quizResult = quizResult; }
  public void setQuizNo(int quizNo) { this.quizNo = quizNo; }
  public void setQuizChapterId(int quizChapterId) { this.quizChapterId = quizChapterId; }
  public void setQuizId(int quizId) { this.quizId = quizId; }
  public void setQuiz(String quiz) { this.quiz = quiz; }
  public void setQuizFlg(String quizFlg) { this.quizFlg = quizFlg; }
  public void setAnswerNum(int answerNum) { this.answerNum = answerNum; }
  public void setCorrAnswerNum(int corrAnswerNum) { this.corrAnswerNum = corrAnswerNum; }
  public void setAnswerId(int[] answerId) { this.answerId = answerId; }
  public void setAnswer(String[] answer) { this.answer = answer; }
  public void setAnswerFlg(String[] answerFlg) { this.answerFlg = answerFlg; }
  public void setAnsweredFlg(String[] answeredFlg) { this.answeredFlg = answeredFlg; }
  public void setJudgeFlg(String[] judgeFlg) { this.judgeFlg = judgeFlg; }
}